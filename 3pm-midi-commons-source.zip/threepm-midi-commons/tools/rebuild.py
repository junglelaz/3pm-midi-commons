#!/usr/bin/env python3
"""Rebuild the 2,400 released MIDI files from 100 base parts (standard library)."""
from pathlib import Path
import argparse
import json
import sys

sys.path.insert(0,str(Path(__file__).parent))
from convert_patterns import encode
from verify_library import read_midi

KEYS={'major':[('C',0),('Db',1),('D',2),('Eb',3),('E',4),('F',5),('Gb',6),('G',7),('Ab',8),('A',9),('Bb',10),('B',11)],
      'minor':[('C',0),('C#',1),('D',2),('Eb',3),('E',4),('F',5),('F#',6),('G',7),('G#',8),('A',9),('Bb',10),('B',11)]}
MAJOR=[0,2,4,5,7,9,11]

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    args=parser.parse_args();source=Path(__file__).resolve().parents[1]/'data/base-patterns.json'
    patterns=json.loads(source.read_text())['patterns'];count=0
    for mode,keys in KEYS.items():
        for tonic,pc in keys:
            offsets=MAJOR if mode=='major' else [0,2,3,5,7,8,10]
            key=tonic.replace('#','sharp')+'_'+mode.title()
            for base in patterns:
                def pitch(n):
                    octave,remainder=divmod(n-6,12)
                    return 6+(pc-6+6)%12-6+12*octave+offsets[MAJOR.index(remainder)]
                name=f"{base['name']}_{base['bpm']}BPM_{key}_8Bars"
                p={**base,'name':name,'provenance':'','key':{'tonic':tonic,'mode':mode},
                   'notes':[{**n,'pitch':pitch(n['pitch'])} for n in base['notes']]}
                path=args.output/('01_Major' if mode=='major' else '02_Minor')/key/p['instrument']/(name+'.mid')
                data,_,_=encode(p)
                if path.exists() and path.read_bytes()!=data:raise FileExistsError(path)
                path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
                parsed=read_midi(path)
                assert parsed['end_tick']==15360 and len(parsed['notes'])==len(p['notes'])
                count+=1
    assert count==2400;print('Rebuilt and verified 2,400 MIDI files.')

if __name__=='__main__':main()
