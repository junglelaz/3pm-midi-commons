#!/usr/bin/env python3
"""Read saved SMF bytes independently and verify notes, metadata and boundaries."""
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]

def read_midi(path):
    data = path.read_bytes()
    assert data[:4] == b'MThd'
    assert struct.unpack('>IHHH', data[4:14]) == (6, 0, 1, 480)
    assert data[14:18] == b'MTrk'
    size = int.from_bytes(data[18:22], 'big')
    assert len(data) == 22 + size
    pos, tick, notes, active, metadata = 22, 0, [], {}, {}
    def variable():
        nonlocal pos
        value = 0
        for _ in range(4):
            byte = data[pos]; pos += 1
            value = value * 128 + (byte & 127)
            if byte < 128:
                return value
        raise AssertionError('Invalid variable-length quantity')
    while pos < len(data):
        tick += variable()
        status = data[pos]; pos += 1
        if status == 255:
            kind = data[pos]; pos += 1
            n = variable(); payload = data[pos:pos+n]; pos += n
            metadata[kind] = payload
            if kind == 47:
                assert n == 0 and pos == len(data) and not active
                break
        else:
            if status & 240 == 192:
                metadata['program'] = data[pos]; pos += 1
                continue
            assert status & 240 in (128, 144)
            pitch, velocity = data[pos:pos+2]; pos += 2
            voice = (status & 15, pitch)
            if status & 240 == 144 and velocity:
                assert voice not in active
                active[voice] = (tick, velocity)
            else:
                start, vel = active.pop(voice)
                notes.append((start, tick-start, pitch, vel, voice[0]))
    assert 47 in metadata
    return dict(end_tick=tick, notes=sorted(notes), metadata=metadata)

def main():
    source = json.loads((ROOT/'source/gemini_patterns.json').read_text())['patterns']
    manifest = json.loads((ROOT/'library/manifest.json').read_text())
    report = []
    for pattern, record in zip(source, manifest):
        parsed = read_midi(ROOT/'library'/record['file'])
        expected = sorted((n['start_tick'], n['duration_ticks'], n['pitch'], n['velocity'], n.get('channel', 0)) for n in pattern['notes'])
        assert parsed['notes'] == expected
        assert parsed['end_tick'] == 15360
        assert parsed['metadata'][81] == bytes.fromhex('0a2c2b')
        assert parsed['metadata'][88] == bytes([4, 2, 24, 8])
        assert parsed['metadata'][89] == bytes([250, 0])
        assert min(n[0] for n in parsed['notes']) == 0
        report.append(dict(file=record['file'], result='PASS', note_count=len(expected),
            end_tick=15360, quarter_note_beats=32, bars=8, ppq=480,
            tempo_microseconds_per_quarter=666667, bpm_encoded=60_000_000/666667,
            duration_seconds=32*666667/1_000_000, key_signature='Gb major (-6 flats)',
            notes_unchanged=True, hanging_notes=0))
    full = read_midi(ROOT/'library'/manifest[0]['file'])
    original = read_midi(ROOT/'source/Gemini_Original_Metadata_90BPM_8Bars.mid')
    assert original['notes'] == full['notes'] and original['end_tick'] == full['end_tick']
    assert original['metadata'] == {81: bytes.fromhex('0a2c2b'), 88: bytes([4,2,24,8]), 47: b''}
    assert sorted(read_midi(ROOT/'library'/manifest[1]['file'])['notes'] + read_midi(ROOT/'library'/manifest[2]['file'])['notes']) == full['notes']
    (ROOT/'verification.json').write_text(json.dumps(dict(status='PASS', original_note_count=73,
        original_matches_tagged_notes=True, extracted_parts_recombine_exactly=True,
        daw_application_test='Not performed', files=report), indent=2)+'\n')
    print('PASS: 73 original notes; 64 melody + 9 bass; exact 8 bars; tempo/key; no hanging notes.')

if __name__ == '__main__':
    main()
