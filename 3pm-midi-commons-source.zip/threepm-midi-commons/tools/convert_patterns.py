#!/usr/bin/env python3
"""Non-generative JSON -> Standard MIDI File batch converter. Python standard library only."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import struct

MAJOR = {'Cb': -7, 'Gb': -6, 'Db': -5, 'Ab': -4, 'Eb': -3, 'Bb': -2,
         'F': -1, 'C': 0, 'G': 1, 'D': 2, 'A': 3, 'E': 4, 'B': 5, 'F#': 6, 'C#': 7}
MINOR = {'Ab': -7, 'Eb': -6, 'Bb': -5, 'F': -4, 'C': -3, 'G': -2,
         'D': -1, 'A': 0, 'E': 1, 'B': 2, 'F#': 3, 'C#': 4, 'G#': 5, 'D#': 6, 'A#': 7}

def integer(value, lo, hi, label):
    if type(value) is not int or not lo <= value <= hi:
        raise ValueError(f'{label} must be an integer from {lo} to {hi}')
    return value

def safe(value):
    s = re.sub(r'[^A-Za-z0-9_-]+', '_', str(value).replace('#', 'sharp')).strip('_')
    if not s:
        raise ValueError('Empty filename label')
    return s

def vlq(n):
    integer(n, 0, 0x0fffffff, 'delta ticks')
    out = [n & 127]
    n >>= 7
    while n:
        out.append((n & 127) | 128)
        n >>= 7
    return bytes(reversed(out))

def meta(kind, data):
    return bytes([255, kind]) + vlq(len(data)) + data

def encode(pattern, original_metadata=False):
    ppq = integer(pattern['ppq'], 1, 32767, 'ppq')
    bars = integer(pattern['bars'], 1, 10000, 'bars')
    numerator, denominator = pattern['time_signature']
    integer(numerator, 1, 255, 'time signature numerator')
    if denominator not in (1, 2, 4, 8, 16, 32, 64):
        raise ValueError('Unsupported time signature denominator')
    length = bars * ppq * 4 * numerator // denominator
    if bars * ppq * 4 * numerator % denominator or length > 0x0fffffff:
        raise ValueError('Loop length cannot be encoded exactly')
    bpm = pattern['bpm']
    if type(bpm) not in (int, float) or not math.isfinite(bpm) or bpm <= 0:
        raise ValueError('bpm must be positive and finite')
    tempo = integer(int(60_000_000 / bpm + 0.5), 1, 0xffffff, 'MIDI tempo')
    mode = pattern['key']['mode']
    if mode not in ('major', 'minor'):
        raise ValueError('Key mode must be major or minor')
    sf = (MAJOR if mode == 'major' else MINOR)[pattern['key']['tonic']]
    events = [(0, meta(0x51, tempo.to_bytes(3, 'big'))),
              (0, meta(0x58, bytes([numerator, denominator.bit_length()-1, 24, 8])))]
    if not original_metadata:
        events += [(0, meta(0x59, struct.pack('bB', sf, mode == 'minor'))),
                   (0, meta(0x03, pattern['name'].encode('utf-8'))),
                   (0, meta(0x01, pattern['provenance'].encode('utf-8')))]
        if 'gm_program' in pattern:
            program = integer(pattern['gm_program'], 0, 127, 'GM program')
            events += [(0, meta(0x04, pattern['instrument'].encode('utf-8'))),
                       (0, bytes([0xc0, program]))]
    if not pattern['notes']:
        raise ValueError('A pattern needs at least one supplied note')
    for note in pattern['notes']:
        start = integer(note['start_tick'], 0, length-1, 'note start')
        dur = integer(note['duration_ticks'], 1, length, 'note duration')
        pitch = integer(note['pitch'], 0, 127, 'pitch')
        vel = integer(note['velocity'], 1, 127, 'velocity')
        channel = integer(note.get('channel', 0), 0, 15, 'channel')
        if start + dur > length:
            raise ValueError('Note extends beyond the declared loop; source needs correction')
        events += [(start, bytes([0x90 | channel, pitch, vel])),
                   (start+dur, bytes([0x80 | channel, pitch, 0]))]
    # Reject ambiguous overlapping voices of the same pitch on the same channel.
    active = set()
    events.sort(key=lambda e: (e[0], 0 if e[1][0] & 0xf0 == 0x80 else 1))
    for _, event in events:
        kind = event[0] & 0xf0
        if kind in (0x80, 0x90):
            voice = (event[0] & 15, event[1])
            if kind == 0x90:
                if voice in active:
                    raise ValueError('Overlapping same-pitch notes on the same channel')
                active.add(voice)
            else:
                active.remove(voice)
    events.append((length, b'\xff\x2f\x00'))
    track, last = bytearray(), 0
    for tick, data in events:
        track += vlq(tick-last) + data
        last = tick
    data = b'MThd' + struct.pack('>IHHH', 6, 0, 1, ppq)
    data += b'MTrk' + struct.pack('>I', len(track)) + track
    return data, length, tempo

def export_batch(document, output):
    prepared = []
    paths = set()
    for p in document['patterns']:
        data, length, tempo = encode(p)
        key = safe(p['key']['tonic']) + '_' + p['key']['mode'].title()
        relative = Path(safe(p['instrument'])) / safe(p['style']) / (safe(p['bpm'])+'BPM') / key
        relative /= f"{safe(p['name'])}_{safe(p['bpm'])}BPM_{key}_{p['bars']}Bars.mid"
        if str(relative).lower() in paths:
            raise ValueError('Duplicate output filename')
        paths.add(str(relative).lower())
        prepared.append((relative, data, dict(file=relative.as_posix(), name=p['name'],
            bpm_requested=p['bpm'], bpm_encoded=60_000_000/tempo,
            tempo_microseconds_per_quarter=tempo, key=key, bars=p['bars'], ppq=p['ppq'],
            end_tick=length, time_signature=p['time_signature'], note_count=len(p['notes']),
            provenance=p['provenance'], dawn_status='Unconfirmed; not represented as DAWN-approved',
            sha256=hashlib.sha256(data).hexdigest())))
    targets = [output / r for r, _, _ in prepared] + [output / 'manifest.json']
    if any(p.exists() for p in targets):
        raise FileExistsError('Output already exists; choose a fresh output folder')
    for relative, data, _ in prepared:
        path = output / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'manifest.json').write_text(json.dumps([r for _, _, r in prepared], indent=2)+'\n')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    export_batch(json.loads(args.source.read_text()), args.output)
